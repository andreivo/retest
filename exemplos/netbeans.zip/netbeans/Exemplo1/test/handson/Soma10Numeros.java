/*
 * ****************************************************************
 *                        André Ivo
 *                   andre.ivo@gmail.com
 *           Created on : Oct 25, 2016, 4:09:37 PM
 * ****************************************************************
 */
package handson;

import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;
import org.retest.ReTestRunner;

/**
 *
 * @author root
 */
@RunWith(ReTestRunner.class)
public class Soma10Numeros {

    @Test
    public void test() {
        fail("Not yet implemented");
    }

}
