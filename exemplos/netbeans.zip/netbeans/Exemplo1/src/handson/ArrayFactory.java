package handson;


import java.util.Random;

/**
 *
 * @author andreivo
 */
public class ArrayFactory {

    public static int[] gerarArrayComSomatoriaZero(int n, Random r) {
        int[] result = new int[1];
        result[0] = 0;
        return result;
    }
}
