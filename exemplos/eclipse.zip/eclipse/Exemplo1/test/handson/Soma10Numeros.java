package test.handson;

import static org.junit.Assert.*;

import org.junit.Test;

public class Soma10Numeros {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
